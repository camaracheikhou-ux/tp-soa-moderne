package fr.ipsl.soa.commandes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceCommandesApplicationTests {

	@Test
	void contextLoads() {
	}

}
